const cloud = require('wx-server-sdk')

cloud.init()

let db = cloud.database();
exports.main = async (event, context) => {
    if(event.isCollect == true)//添加收藏
    {
        return await db.collection('collect').add({
            data: {
                _openid: event._openid,
                name: event.name,
                desc: event.desc
            }
        }).then(res => {
            console.log("添加成功", res)
            
            return res
        });
    }
    else//取消收藏
    {
        return await db.collection('collect').where({
            _openid: event._openid,
            name: event.name,
            desc: event.desc
        }).remove().then(res => {
            return res
        })
    }
    
}