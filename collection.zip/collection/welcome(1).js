// pages/welcome/welcome.js
const app=getApp();
const db=wx.cloud.database();
Page({

    /**
     * 页面的初始数据
     */
    data: {
        //welcome:"cloud://vnt-4g4bf7761a0e80d5.766e-vnt-4g4bf7761a0e80d5-1304485632/logo.png",
        //welcome:'cloud://vnt-4g4bf7761a0e80d5.766e-vnt-4g4bf7761a0e80d5-1304485632/20346.561903146874.png',
        welcome:'../../static/img/logo.png',
        msg:'',
        T:null
    },
    /**
     * 生命周期函数--监听页面加载
     */
    onLoad: function (options) {
        var date=new Date();
        var tc=date.toLocaleDateString()+" 00:00:00"
        console.log(new Date(tc).getTime()/1000);
        const timeUrl=(new Date("2021/9/21 00:00:00")).getTime()/1000;
        this.setData({
            msg:'加餐食 - 长相忆',
            welcome:'../../static/img/index/'+timeUrl+'.jpg'
        })        
    },
    onShow: function () {
        /*
        this.T=setTimeout(function(){
            wx.switchTab({
                url: '../index/index',
            })
            // wx.redirectTo({
            //   url: '../calendar/calendar',
            // })
        },3000)
        */
       this.T=setTimeout(() => {
            this.checkLogin();           
       }, 2000);

    },
    toIndex:function(){
        clearInterval(this.T)
        wx.switchTab({
          url: '../user/user',
        })
    },
    onHide: function () {

    },
    onUnload: function () {

    },
    /**
     * 用户点击右上角分享
     */
    onShareAppMessage: function () {

    },
    checkLogin(){
        // 调用云函数
        wx.cloud.callFunction({
            name: 'login',
            data: {},
            success: res => {
            console.log('[云函数] [login] user openid: ', res.result.openid)
            app.globalData.openid = res.result.openid
            app.globalData.appid=res.result.appid
            db.collection('users').where({
                _openid:res.result.openid
            }).get().then(re=>{
                if(re.data.length==0){
                console.log('用户尚未注册','res.result.openid=',res.result.openid);            
                wx.redirectTo({
                  url: '../calendar/calendar',
                })
                // wx.switchTab({
                //   url: '../user/user',
                // })
                }else{
                    console.log('用户已经注册')            
                    wx.switchTab({
                        url: '../user/user',
                    })            
                }
            })
            },
            fail: err => {
                console.error('[云函数] [login] 调用失败', err)
                wx.navigateTo({
                    url: '../deployFunctions/deployFunctions',
                })
            }
        })
    }
})