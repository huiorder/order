export declare const behavior: string;
