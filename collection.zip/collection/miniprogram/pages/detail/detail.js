const db = wx.cloud.database()
const collect = db.collection("collect")
Page({
    data :{
        detail: '',
        isCollect: false,
        openid: ''
    },
    onLoad(options){
        var col = this.data.isCollect
        db.collection("order").doc(options.id).get().then(res => {
            this.setData({
                detail: res.data
            })

            //显示收藏状态（灰色/黄色）
            //方法一：直接传入openID（需要提前获取openID）
            collect.where({
                _openid: "o-A5w5dm9GL6zDQFXfwSNUA4zRX8",//使用提前获取到的openID
                name: this.data.detail.name,
                desc: this.data.detail.desc
            }).get().then(res2 => {
                if(res2.data.length){//已收藏，显示黄色
                    this.setData({
                        isCollect:!col
                    });
                    this.data.isCollect = true;
                }
                else{//未收藏，显示灰色
                    this.setData({
                        isCollect:false
                    });
                    this.data.isCollect = false;
                }
            })

            // 方法二：调用云函数获得openID，但由于云函数延后执行，导致图标无法显示
            //此处未注释的步骤是为后续的点击收藏tocollect步骤获取openID
            var that = this
            wx.cloud.callFunction({
            name: 'getOpenid',
            success: function(res) {
                //console.log("云函数调用成功！",res)
                that.setData({
                openid: res.result.openid
                })

                //下面注释掉的是方法二，利用云函数显示图标的步骤
                // collect.where({
                //     _openid: that.data.openid,
                //     name: that.data.detail.name,
                //     desc: that.data.detail.desc
                // }).get().then(res => {
                //     console.log("that.data.isCollect", that.data.isCollect)
                //     console.log("col", col)
                //     if(res.data.length)
                //     {
                //         that.data.isCollect = !col;
                //     }
                //     console.log("that.data.isCollect", that.data.isCollect)
                // })
                // console.log("isCollect", this.data.isCollect)
            },
            fail: function(error) {
                console.log("云函数调用失败！",error)
            },
        })
    })   
    .catch(res => {
        console.log("详情页失败", res)
    })
    
},
    toCollect () {//点击收藏图标要执行的收藏/取消收藏步骤
        var col = this.data.isCollect; // 获取状态
        console.log("this.data.openid", this.data.openid)
        this.setData({
            isCollect:!col // 改变状态
            });
        wx.cloud.callFunction({//更改收藏状态
            name: "CollectionData",
            data: {
                isCollect: this.data.isCollect,
                _openid: this.data.openid,
                name: this.data.detail.name,
                desc: this.data.detail.desc
            }
        }).then(res =>{
            console.log(res.result)
            if(this.data.isCollect == true)
            {
                wx.showToast({
                    title: '收藏成功',
                    icon: 'success',
                    duration: 1000
                })
            }
        })
    }
})
