//将收藏功能放在了detail页面的小星星上，调用云函数login（无修改）和CollectionData，叔叔写的checkLogin有修改，也改了函数名叫myCheckLogin
const db = wx.cloud.database()
const collect = db.collection("collect")
const app=getApp()
Page({
    data :{
        detail: '',
        isCollect: false,
        _openid: ''
    },
    onLoad(options){
        this.myCheckLogin()
        db.collection("order").doc(options.id).get().then(res => {
            this.setData({
                detail: res.data
            })
    })   
    .catch(res => {
        console.log("详情页失败", res)
    })
},
    getStatus(){
        var col = this.data.isCollect
        collect.where({
            _openid: this.data._openid,//使用提前获取到的openID
            name: this.data.detail.name,
            desc: this.data.detail.desc
        }).get().then(res2 => {
            if(res2.data.length){//已收藏，显示黄色
                this.setData({
                    isCollect:!col
                });
                this.data.isCollect = true;
            }
            else{//未收藏，显示灰色
                this.setData({
                    isCollect:false
                });
                this.data.isCollect = false;
            }
        })
    },
    myCheckLogin(){
        // 调用云函数
        wx.cloud.callFunction({
            name: 'login',
            data: {},
            success: res => {
            //console.log('[云函数] [login] user openid: ', res.result.openid)
            this.setData({
                _openid: res.result.openid
            })
            this.getStatus()
            app.globalData.openid = res.result.openid
            app.globalData.appid=res.result.appid
            },
            fail: err => {
                console.error('[云函数] [login] 调用失败', err)
            }
        })
    },
    toCollect () {//点击收藏图标要执行的收藏/取消收藏步骤
        var col = this.data.isCollect; // 获取状态
        this.setData({
            isCollect:!col // 改变状态
            });
        wx.cloud.callFunction({//更改收藏状态
            name: "CollectionData",
            data: {
                isCollect: this.data.isCollect,
                _openid: this.data._openid,
                name: this.data.detail.name,
                desc: this.data.detail.desc
            }
        }).then(res =>{
            if(this.data.isCollect == true)
            {
                wx.showToast({
                    title: '收藏成功',
                    icon: 'success',
                    duration: 1000
                })
            }
        })
    }
})
