//只是详情页面的入口，与收藏功能无关
const db = wx.cloud.database()
Page({
    data: {
        datalist: [],
    },
    onLoad(){
        db.collection('order').get().then(res => {
            this.setData({
                datalist: res.data
            })
        })
        .catch(res => {
            console.log("获取失败", res)
        })
    },
    detail(event){
        //console.log("点击获取数据", event.currentTarget.dataset.item._id)
        
        wx.navigateTo({
          url: '/pages/detail/detail?id=' + event.currentTarget.dataset.item._id,
        })
    }
})