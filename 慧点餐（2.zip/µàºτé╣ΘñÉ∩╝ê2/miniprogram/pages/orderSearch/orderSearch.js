// pages/orderSearch/orderSearch.js
const db=wx.cloud.database();
Page({

  /**
   * 页面的初始数据
   */
  data: {
    value: '',
  },
 
  onChange(e) {
    this.setData({
      value: e.detail,
    });
    wx.navigateTo({
      url: '../Search/Search',
    })
  },
  
})