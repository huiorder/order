// pages/orderMine/orderMine.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    loading: true,
  },

  onReady() {
    this.setData({
      loading: false,
    });
  },
})