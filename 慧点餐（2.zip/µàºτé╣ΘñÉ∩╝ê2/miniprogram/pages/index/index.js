// miniprogram/pages/index/index.js
const db = wx.cloud.database();
const todos = db.collection('Todos')
Page({
  data: {
    tasks: [],
    //底栏
    active: 'home',
    //滑动标签
    activetabs:1,
    //轮播图
    image: null,
    background: ['demo-text-1', 'demo-text-2', 'demo-text-3'],
    indicatorDots: true,
    vertical: true,
    autoplay: true,
    interval: 5000,
    duration: 500,
  }, 

  //底栏
  onChange(event) {
    // event.detail 的值为当前选中项的索引
    this.setData({
      active: event.detail,

    });
    console.log(event.detail)
    if (event.detail == 'search') {
      wx.navigateTo({
        url: '../orderSearch/orderSearch',
      })
    }
    else if (event.detail == 'setting') {
      wx.navigateTo({
        url: '../orderSetting/orderSetting',
      })
    }
    else if (event.detail == 'home') {
      wx.navigateTo({
        url: '../index/index',
      })
    }
    else if (event.detail == 'mine') {
      wx.navigateTo({
        url: '../orderMine/orderMine',
      })
    }

  },
  //推荐的数据加载
  onLoad: function (options) {
    this.getData();//把res=>{}隐藏掉
  },
  onPullDownRefresh: function () {
    this.getData(res => {
      wx.stopPullDownRefresh();
      this.pageData.skip = 0
      this.data.tasks = []
    });
  },

  onReachBottom: function () {
    this.getData();//加载数据尽量每次都用getData
  },
  getData: function (callback) {
    if (!callback) {
      callback = res => { }
    }
    wx.showLoading({
      title: '数据加载中',
    })
    todos.skip(this.pageData.skip).get().then(res => {
      let oldData = this.data.tasks;
      console.log(res)
      this.setData({
        tasks: oldData.concat(res.data)//将触底后的数据拼接进去
      }, res => {
        // 完成第一次跳过后要对skip进行一个增加
        this.pageData.skip = this.pageData.skip + 20
        wx.hideLoading()
        callback();
      })
    })
  },
  pageData: {
    skip: 0
  }
})