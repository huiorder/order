// pages/Search/Search.js
const db = wx.cloud.database();
Page({

  data: {
    value: '',
    output: [],
  },

  onChange(e) {
    this.setData({
      value: e.detail,
    });
    
  },
  onSearch() {
    console.log(this.data.value)
    // Toast('搜索' + this.data.value);
  },
  onClick() {
    console.log(this.data.value)

    this.queryZhengze();
    // Toast('搜索' + this.data.value);
  },

  queryZhengze: function () {
    // wx.showLoading({
    //   title: '加载中',
    // })
    console.log("Query")
    db.collection("Todos")
      .where({
        title: new db.RegExp({
          regexp: this.data.value,
          option: 'i'
        })
      })
      .get({
        success: res => {
          this.setData({
            output: res.data
          })
          console.log(res.data)//在控制台上呈现
        }
      })
  }
})