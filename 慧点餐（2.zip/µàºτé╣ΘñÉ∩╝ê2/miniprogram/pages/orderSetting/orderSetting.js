// pages/orderSetting/orderSetting.js
Page({

  data: {
    active: 'setting',
  },

  onChange(event) {
    // event.detail 的值为当前选中项的索引
    this.setData({
      active: event.detail,

    });
    console.log(event.detail)
    if (event.detail == 'search') {
      wx.navigateTo({
        url: '../orderSearch/orderSearch',
      })
    }
    else if (event.detail == 'setting') {
      wx.navigateTo({
        url: '../orderSetting/orderSetting',
      })
    }
    else if (event.detail == 'home') {
      wx.navigateTo({
        url: '../index/index',
      })
    }
    else if (event.detail == 'mine') {
      wx.navigateTo({
        url: '../orderMine/orderMine',
      })
    }
  },
})