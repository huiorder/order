const db = wx.cloud.database()
const cart = db.collection('cart')
import Dialog from 'vant-weapp/dialog/dialog';
import Toast from 'vant-weapp/toast/toast';
var util = require('../../utils/util.js')
const app=getApp()

Page({
    data: {
      _openid: '',
      radio: '',
      getWay: '',
      location: '',
      user_daiqu: '',
      money: '',
      cart: [],
      message: '无',
      time: [],
      status: false,
      total: 0
    },
    
    myCheckLogin(){
      // 调用云函数
      wx.cloud.callFunction({
          name: 'login',
          data: {},
          success: res => {
          //console.log('[云函数] [login] user openid: ', res.result.openid)
          this.setData({
              _openid: res.result.openid
          })
          //this.getLocation()
          app.globalData.openid = res.result.openid
          app.globalData.appid=res.result.appid
          },
          fail: err => {
              console.error('[云函数] [login] 调用失败', err)
          }
      })
    },
    onChange(event) {
        this.setData({
          radio: event.detail,
        });
      },
    onClick(event) {
        const { name } = event.currentTarget.dataset;
        this.setData({
          radio: name,
        });
        console.log(this.data.radio)
        if(this.data.radio == 2){
          Dialog.confirm({
            title: '提示',
            message: '为避免因无人接单而导致食物浪费，若五分钟内无人接单，则自动取消订单。\n请确认是否选择代取餐',
          })
            .then(() => {
              this.setData({
                location: '',
                user_daiqu: '', 
                money: '',
              })
              this.confirm()
            })
            .catch(() => {
              this.cancel()
            })
        }
      },
    //点击确认后去完善代取餐信息
    confirm(){
      wx.navigateTo({
        url: '/pages/dai_qu/dai_qu',
      })
    },
    //点击取消自动变成“自取”
    cancel(){
      this.data.radio = '1',
      this.setData({
        radio: '1'
      })
    },
    onLoad() {
        //获取openid
        this.myCheckLogin()
        //获取当前时间
        // 调用函数时，传入new Date()参数，返回值是日期和时间
        var time = util.formatTime(new Date());
        time = time.split(" ")[0].split("/"),
        this.setData({
          time:time
        });
        //展示用户订单详情
        cart.where({
          _openid: "o-A5w5dm9GL6zDQFXfwSNUA4zRX8"
        }).get().then(res => {
          var total = 0;
          for(var i = 0; i < res.data.length; i ++)
          {
            total = total + (res.data[i].price * res.data[i].number)
          }
          total = total * 100
          this.setData({
            cart: res.data,
            total: total
          })
        })
    },
    onPlus(event){
      //小聪的代码中的menuid改成了_id
      const dataset = event.currentTarget.dataset
      const _id = dataset.menuid
      const cartArr = this.data.cart
      let i=0
      let price = 0
      let total = this.data.total / 100
      const len = cartArr.length
      for(i=0;i<len;i++)
      {
        if(cartArr[i]._id == _id)
        {
          cartArr[i].number++;
          price = Number(cartArr[i].price);
          total = total + price;
          break
        }
      }
      if(i == cartArr.length)//购物车中没有匹配的menuid
      {
        this.data.cart[len] = {
          _id: _id,
          number:1
        }
      }
      total = total * 100;
      this.setData({
        total: total
      })
      console.log(this.data.cart)
    },
    onMinus(event){
      //menuid改成了_id
      const dataset = event.currentTarget.dataset
      const _id = dataset.menuid
      const cartArr = this.data.cart
      let i=0
      let j=0
      let price = 0
      let total = this.data.total / 100
      const len = cartArr.length
      for(i=0;i<len;i++)
      {
        if(cartArr[i]._id == _id)
        {
          cartArr[i].number--;
          price = Number(cartArr[i].price);
          total = total - price;
          break
        }
      }
      total = total * 100;
      this.setData({
        total: total
      })
      console.log(this.data.cart)
    },
    onClickButton(){
      if(this.data.radio == ''){
        Toast.fail('请选择取餐方式');
      }
      else if((this.data.radio == '2') && ((this.data.location == '') || (this.data.user_daiqu == '') || (this.data.money == ''))){
        Toast.fail('请完善代取信息');
      }
      else{
        //将订单信息加入orders数据库
        if(this.data.radio == '1'){
          this.data.getWay = '自取'
        }
        else if(this.data.radio == '2'){
          this.data.getWay = '代取'
        }
        //如果商品数量减为零，则将cart中对应商品改为null
        const cartArr = this.data.cart
        const len = cartArr.length
        console.log("cart",this.data.cart)
        for(let i = 0; i < len; i ++){
          if(cartArr[i].number == 0){
            cartArr[i] = null
          }
        }
        //将订单加入orders数据库
        wx.cloud.callFunction({
          name: "OrderData",
          data: {
              using: 'add',
              getWay: this.data.getWay,
              _openid: this.data._openid,
              location: this.data.location,
              user_daiqu: this.data.user_daiqu,
              money: this.data.money,
              cart: this.data.cart,
              message: this.data.message,
              time: this.data.time,
              status: this.data.status
          }
        }).then(res => {
            console.log(res)
            Toast.success('下单成功');
            wx.setStorage({
                key: "_openid",
                data: this.data._openid
              }),
            wx.setStorage({
              key: "getWay",
              data: this.data.getWay
            }),
            wx.setStorage({
              key: "location",
              data: this.data.location
            }),
            wx.setStorage({
              key: "user_daiqu",
              data: this.data.user_daiqu
            }),
            wx.setStorage({
              key: "money",
              data: this.data.money
            }),
            wx.setStorage({
              key: "cart",
              data: this.data.cart
            }),
            wx.setStorage({
              key: "message",
              data: this.data.message
            }),
            wx.setStorage({
              key: "total",
              data: this.data.total
            }),
            wx.setStorage({
              key: "time",
              data: this.data.time
            }),
            wx.setStorage({
              key: "status",
              data: this.data.status
            }),
            wx.redirectTo({
                url: '/pages/finish/finish',
            })
        })

        //若为代取（radio == 2）则需连接到支付界面
      }
    },
})