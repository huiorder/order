const db = wx.cloud.database()
const orders = db.collection('orders')
Page({

    /**
     * 页面的初始数据
     */
    data: {
        _openid: '',
        getWay: '',
        location: '',
        user_daiqu: '',
        money: '',
        cart: [],
        message: '',
        time: [],
        status: false,
        total: 0.00,
        onLoadTime: ''
      },
    onLoad: function (options) {
        var _openid = wx.getStorageSync('_openid');
        var getWay = wx.getStorageSync('getWay');
        var location = wx.getStorageSync('location');
        var user_daiqu = wx.getStorageSync('user_daiqu');
        var money = wx.getStorageSync('money');
        var cart = wx.getStorageSync('cart');
        var message = wx.getStorageSync('message');
        var total = wx.getStorageSync('total') / 100;
        var time = wx.getStorageSync('time');
        var status = wx.getStorageSync('status');
        this.setData({
            _openid: _openid,
            getWay: getWay,
            location: location,
            user_daiqu: user_daiqu,
            money: money,
            cart: cart,
            message: message,
            total: total,
            time: time,
            status: status,
        })
        var time = this.data.time[0]+"年" + this.data.time[1]+"月" + this.data.time[2]+"日" + this.data.time[3]+"时" + this.data.time[4]+"分" + this.data.time[5]+"秒"
        this.setData({
            onLoadTime: time
        })
    },
})