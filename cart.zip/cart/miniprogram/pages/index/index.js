import Toast from 'vant-weapp/toast/toast';
const db = wx.cloud.database()
const menu = db.collection('menu')
const users = db.collection('users')
Page({
  data: {
    menu:[],
    cart:[],
    imageURL:'cloud://test-hui-mevnk.7465-test-hui-mevnk-1304215355/1667059003.png',
    show: false,
    show: false,
    actions: [
      {
        name: '选项',
      },
      {
        name: '选项',
      },
      {
        name: '选项',
        subname: '描述信息',
        openType: 'share',
      },
    ],
  },

  onLoad:function(options){
    wx.cloud.callFunction({
      name:"curd",
      data:{
        dbName:'users',
        curd:'get',
        where:{
          _id:'b00064a7601a583502947a25582e27b6'//在users集合中找到该id用户
        },
        data:null
      },
      success:res=>{
        const cartArr = res.result.data[0].cart//获取该用户cart数组
        console.log(cartArr)
        this.setData({
          cart:cartArr//将该数组写入本地cart数组中
        })
        menu.get().then(res => {
          const menuArr = res.data
          for(let i=0;i<menuArr.length;i++)
          {
            menuArr[i].number = 0
            for(let j=0;j<cartArr.length;j++)
            {
              if(menuArr[i]._id == cartArr[j].menuid)
              {
                menuArr[i].number = cartArr[j].number
              }
            }
          }
          console.log(menuArr)
          this.setData({
            menu:menuArr
          })
        })
      }
    })

  },

  onPlus:function(event){
    const dataset = event.currentTarget.dataset
    const menuid = dataset.menuid
    console.log(menuid)
    const cartArr = this.data.cart
    let i=0
    const len = cartArr.length
    for(i=0;i<len;i++)
    {
      if(cartArr[i].menuid == menuid)
      {
        cartArr[i].number++
        break
      }
    }
    if(i == cartArr.length)//购物车中没有匹配的menuid
    {
      this.data.cart[len] = {
        menuid:menuid,
        number:1
      }
    }
    console.log(this.data.cart)
  },

  onMinus:function(event){
    const dataset = event.currentTarget.dataset
    const menuid = dataset.menuid
    console.log(menuid)
    const arr = this.data.cart
    for(let i=0;i<arr.length;i++)
    {
      if(arr[i].menuid == menuid)
      {
        arr[i].number--
      }
    }
    console.log(arr)
  },

  upload:function(event){
    wx.cloud.callFunction({
      name:'curd',
      data:{
        dbName:'users',
        curd:'update',
        where:{
          _id:'b00064a7601a583502947a25582e27b6'
        },
        data:{
          cart:this.data.cart,
        }
      },
      success:function(res){
        if(res.result){
          console.log('数据库更新成功！')
        }else{
          console.log('数据库更新失败！')
        }
        console.log(res)
      },
      fail:console.error
    });
  },

  onDisabled:function(){
    console.log('该商品已售罄！')
    Toast.fail('已售罄！');
  },

  navigateToCart:function(event){
    wx.navigateTo({
      url:'../cartList/cartlist'
    })
  }
})
