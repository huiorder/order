// 云函数入口文件
const cloud = require('wx-server-sdk')
cloud.init()

const db = cloud.database()
// 云函数入口函数
exports.main = async (event, context) => {
    const wxContext = cloud.getWXContext()
    const dbName=event.dbName
    const curd=event.curd
    const data=event.data
    const where=event.where
    if(curd!="add" && curd!="update" && curd!="get" && curd!="d"){
        return {
            status:-1,
            msg:"curd 操作未指定"
        }
    }
    return new Promise((resolve,reject)=>{
        switch(curd){
            case 'add':
                db.collection(dbName).add({
                    data:data
                }).then((res)=>{
                    resolve({
                        status:200,
                        msg:'ok'
                    })
                })
                break;
            case 'update':
                db.collection(dbName).where(where).update({
                    data:data
                }).then(res=>{
                    resolve({
                        status:200,
                        msg:'ok'
                    })
                })
                break;
            case 'get':
                db.collection(dbName).where(where).get().then(res=>{
                    resolve({
                        data:res.data
                    })
                })
                break;
            case 'd':
                break;
            default:
                break;
        }

    })


    // return {
    //     status:200,
    //     msg:"对集合 "+event.dbName+" 进行操作"
    // }
}