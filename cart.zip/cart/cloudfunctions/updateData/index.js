const cloud = require('wx-server-sdk')
cloud.init()
let db = cloud.database()
exports.main = async (event, context) => {
  if(event.tag == 'name')
  {
      return await db.collection('users').doc(event.userid).update({
      data:{
        'cart.1':event.menuid
      }
    })
  }
  else if(event.tag == 'image')
  {
    return await db.collection('menu').doc(event.id).update({
      data:{
        image:event.image
      }
    })
  }
}