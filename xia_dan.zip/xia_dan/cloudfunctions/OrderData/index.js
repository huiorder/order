//添加/删除订单的云函数
const cloud = require('wx-server-sdk')

cloud.init({
    // API 调用都保持和云函数当前所在环境一致
    // env: cloud.DYNAMIC_CURRENT_ENV
})

let db = cloud.database();
exports.main = async (event, context) => {
    if(event.using == 'add')//添加订单
    {
        if(event.radio == '1'){
            return await db.collection('orders').add({
                data: {
                    _openid: event._openid,
                    getWay: '自取',
                    cart: event.cart,
                    message: event.message,
                    time: event.time,
                    status: event.status
                }
            }).then(res => {
                console.log("添加成功", res)
                return res
            });
        }
        else if(event.radio == '2'){
            return await db.collection('orders').add({
                data: {
                    _openid: event._openid,
                    getWay: '代取',
                    location: event.location,
                    user_daiqu: event.user_daiqu,
                    money: event.money,
                    cart: event.cart,
                    message: event.message,
                    time: event.time,
                    status: event.status
                }
            }).then(res => {
                console.log("添加成功", res)
                return res
            });
        }
    }
    // else//取消订单
    // {
    //     return await db.collection('orders').where({
    //         _openid: event._openid,
    //         cart: event.cart,
            
    //     }).remove().then(res => {
    //         return res
    //     })
    // }
    
}