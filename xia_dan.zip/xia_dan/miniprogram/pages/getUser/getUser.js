const db = wx.cloud.database();
Page({
  data: {
    value: '',
    output: [],
    radio: '1',
  },
  getUser(){
    var user= '随机';
    var pages = getCurrentPages();
    var currPage = pages[pages.length - 1];   //当前页面
    var prevPage = pages[pages.length - 2];  //上一个页面
    console.log(prevPage)
    //直接调用上一个页面的setData()方法，把数据存到上一个页面中去
    prevPage.setData({
        user_daiqu: user
    })
    wx.navigateBack({
        delta: 1,
      })
  },
  onChange(e) {
    this.setData({
      value: e.detail,
    });
  },
  onSearch() {
    this.queryZhengze();
  },
  onClick() {
    this.queryZhengze();
  },

  queryZhengze: function () {
    //按学号查询
    db.collection("user")
      .where({
        stu_id: new db.RegExp({
          regexp: this.data.value,
          option: 'i'
        })
      })
      .get({
        success: res => {
          this.setData({
            output: res.data
          })
        }
      })
    //按姓名查询
    db.collection("user")
      .where({
            name: new db.RegExp({
            regexp: this.data.value,
            option: 'i'
            })
        })
        .get({
            success: res => {
            this.setData({
                output: res.data
            })
            }
        })
    
  },
  btnClick(event) {
    const { name } = event.currentTarget.dataset;
    this.setData({
      radio: name,
    });
    var user= this.data.radio;
    var pages = getCurrentPages();
    var currPage = pages[pages.length - 1];   //当前页面
    var prevPage = pages[pages.length - 2];  //上一个页面
    //直接调用上一个页面的setData()方法，把数据存到上一个页面中去
    prevPage.setData({
        user_daiqu: user
    })
    wx.navigateBack()
},
})