const db = wx.cloud.database()
import Toast from 'vant-weapp/toast/toast';
Page({
    data: {
        location: '',
        user_daiqu: '',
        value: '',
    },
    onChange(event) {
        // event.detail 为当前输入的值
        console.log(event.detail.value);
        this.setData({
            value: event.detail.value
        })
    },
    onSubmit(event){
        if((this.data.location === '') || (this.data.user_daiqu === '') || (this.data.value === '')){
            Toast.fail('请完善信息');
        }
        else{
            var local= this.data.location;
            var user= this.data.user_daiqu;
            var money = this.data.value
            var pages = getCurrentPages();
            var currPage = pages[pages.length - 1];   //当前页面
            var prevPage = pages[pages.length - 2];  //上一个页面
            //直接调用上一个页面的setData()方法，把数据存到上一个页面中去
            prevPage.setData({
                location: local,
                user_daiqu: user,
                money: money
            })
            wx.navigateBack()
        }
    },
    onLoad: function (options) {
        
    },

})