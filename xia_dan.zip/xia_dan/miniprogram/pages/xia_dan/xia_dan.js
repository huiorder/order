const db = wx.cloud.database()
const cart = db.collection('cart')
import Dialog from 'vant-weapp/dialog/dialog';
import Toast from 'vant-weapp/toast/toast';
var util = require('../../utils/util.js')
const app=getApp()

Page({
    data: {
      _openid: '',
      radio: '',
      location: '',
      user_daiqu: '',
      money: '',
      cart: [],
      message: '',
      time: [],
      status: false
    },
    onClickButton(){
      if(this.data.radio == ''){
        Toast.fail('请选择取餐方式');
      }
      else if((this.data.radio == '2') && ((this.data.location == '') || (this.data.user_daiqu == '') || (this.data.money == ''))){
        Toast.fail('请完善代取信息');
      }
      else{
        wx.cloud.callFunction({
          
          name: "OrderData",
          data: {
              using: 'add',
              _openid: this.data._openid,
              location: this.data.location,
              user_daiqu: this.data.user_daiqu,
              money: this.data.money,
              cart: this.data.cart,
              message: this.data.message,
              time: this.data.time,
              status: this.data.status
          }
        }).then(res => {
            console.log("success")
        })

        //若为代取（radio == 2）则需连接到支付界面
      }
    },
    myCheckLogin(){
      // 调用云函数
      wx.cloud.callFunction({
          name: 'login',
          data: {},
          success: res => {
          //console.log('[云函数] [login] user openid: ', res.result.openid)
          this.setData({
              _openid: res.result.openid
          })
          //this.getLocation()
          app.globalData.openid = res.result.openid
          app.globalData.appid=res.result.appid
          },
          fail: err => {
              console.error('[云函数] [login] 调用失败', err)
          }
      })
    },
    onChange(event) {
        this.setData({
          radio: event.detail,
        });
      },
    onClick(event) {
        const { name } = event.currentTarget.dataset;
        this.setData({
          radio: name,
        });
        console.log(this.data.radio)
        if(this.data.radio == 2){
          Dialog.confirm({
            title: '提示',
            message: '为避免因无人接单而导致食物浪费，若五分钟内无人接单，则自动取消订单。\n请确认是否选择代取餐',
          })
            .then(() => {
              this.setData({
                location: '',
                user_daiqu: '', 
                money: '',
              })
              this.confirm()
            })
            .catch(() => {
              this.cancel()
            })
        }
      },
    //点击确认后去完善代取餐信息
    confirm(){
      wx.navigateTo({
        url: '/pages/dai_qu/dai_qu',
      })
    },
    //点击取消自动变成“自取”
    cancel(){
      this.data.radio = '1',
      this.setData({
        radio: '1'
      })
    },
    onLoad() {
        //获取openid
        this.myCheckLogin()
        //获取当前时间
        // 调用函数时，传入new Date()参数，返回值是日期和时间
        var time = util.formatTime(new Date());
        time = time.split(" ")[0].split("/"),
        this.setData({
          time:time
        });
        //展示用户订单详情
        cart.where({
          _openid: "o-A5w5dm9GL6zDQFXfwSNUA4zRX8"
        }).get().then(res => {
          this.setData({
            cart: res.data
          })
        })
    },
    onPlus(event){
      //小聪的代码中的menuid改成了_id
      console.log(this.data.message)
      const dataset = event.currentTarget.dataset
      const _id = dataset.menuid
      const cartArr = this.data.cart
      let i=0
      const len = cartArr.length
      for(i=0;i<len;i++)
      {
        if(cartArr[i]._id == _id)
        {
          cartArr[i].number++
          break
        }
      }
      if(i == cartArr.length)//购物车中没有匹配的menuid
      {
        this.data.cart[len] = {
          _id: _id,
          number:1
        }
      }
      console.log(this.data.cart)
    },
    onMinus(event){
      //menuid改成了_id
      const dataset = event.currentTarget.dataset
      const _id = dataset.menuid
      const cartArr = this.data.cart
      let i=0
      const len = cartArr.length
      for(i=0;i<len;i++)
      {
        if(cartArr[i]._id == _id)
        {
          cartArr[i].number--
          break
        }
      }
      console.log(this.data.cart)
    }
})