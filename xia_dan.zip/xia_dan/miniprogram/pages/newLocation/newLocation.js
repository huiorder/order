const db = wx.cloud.database()
const local = db.collection("user_location")
const app=getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        newLocal: '',
        _openid: ''
    },
    onLoad: function (options) {
        this.myCheckLogin()
    },
    myCheckLogin(){
        // 调用云函数
        wx.cloud.callFunction({
            name: 'login',
            data: {},
            success: res => {
            //console.log('[云函数] [login] user openid: ', res.result.openid)
            this.setData({
                _openid: res.result.openid
            })
            //this.getLocation()
            app.globalData.openid = res.result.openid
            app.globalData.appid=res.result.appid
            },
            fail: err => {
                console.error('[云函数] [login] 调用失败', err)
            }
        })
    },
    onChange(event){
        //添加新地址
        this.setData({
            newLocal: event.detail.value
        })
        var local= this.data.newLocal;
        var pages = getCurrentPages();
        var currPage = pages[pages.length - 1];   //当前页面
        var prevPage = pages[pages.length - 3];  //上一个页面
    
        //直接调用上一个页面的setData()方法，把数据存到上一个页面中去
        prevPage.setData({
            location: local
        })
        wx.cloud.callFunction({
            name: 'UserLocation',
            data: {
                using: 'add',
                _openid: this.data._openid,
                location: this.data.newLocal
            },
        }).then(res => {
            console.log("success")
        })
        wx.navigateBack({
          delta: 2,
        })
    }
})