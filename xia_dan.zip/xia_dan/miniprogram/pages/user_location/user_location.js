const db = wx.cloud.database()
const Local = db.collection("user_location")
Page({
    data: {
        location: [],
        radio: '1',
    },
    onLoad() {
        Local.get().then(res => {
            this.setData({
                location: res.data
            })
        })
    },
    addLocation(){
        wx.navigateTo({
          url: '/pages/newLocation/newLocation',
        })
    },
    onChange(event) {
        this.setData({
          radio: event.detail,
        });
    },
    
    onClick(event) {
        const { name } = event.currentTarget.dataset;
        this.setData({
          radio: name,
        });
        var local= this.data.radio;
        var pages = getCurrentPages();
        var currPage = pages[pages.length - 1];   //当前页面
        var prevPage = pages[pages.length - 2];  //上一个页面
        //直接调用上一个页面的setData()方法，把数据存到上一个页面中去
        prevPage.setData({
            location: local
        })
        wx.navigateBack()
    },
})