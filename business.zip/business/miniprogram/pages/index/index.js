Page({
  data: {
  },
  uploadImage:function(event){
    wx.chooseImage({
      count: 1,
      success:function(res){
        console.log(res.tempFilePaths[0])
        wx.cloud.uploadFile({
          cloudPath:'456.png',
          filePath:res.tempFilePaths[0]
        }).then(res => {
          console.log(res.fileID)
          wx.cloud.callFunction({
            name:"updateData",
            data:{
              tag:'image',
              id:'28ee4e3e6012225c0170d81313ff6f05',
              image:res.fileID
            }
          }).then(console.log)
        }).catch(err => {
          console.log(err)
        })
      }
    })

  }
})
