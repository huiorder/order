// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init({
    // API 调用都保持和云函数当前所在环境一致
    env: cloud.DYNAMIC_CURRENT_ENV
  })

  let db = cloud.database();

// 云函数入口函数
exports.main = async (event, context) => {
    if(event.using == 'get'){//获取地址
        return await db.collection('user_location').where({
            _openid: event._openid
        }).get().then(res => {
            return res
        })
    }
    else if(event.using == 'add'){//添加地址
        return await db.collection('user_location').add({
            data: {
                _openid: event._openid,
                location: event.location,
                isDelete: event.isDelete
            }
        }).then(res => {
            return res
        });
    }
    else if(event.using == 'update'){//更新状态（在删除前调用，将isDelete改为true）
        return await db.collection('user_location').where({
            _openid: event._openid,
            location: event.location
        }).update({
            data: {
                isDelete: event.isDelete
            }
        }).then(res => {
            return res
        })
    }
    else if(event.using == 'delete'){//删除地址
        return await db.collection('user_location').where({
            _openid: event._openid,
            isDelete: event.isDelete
        }).remove().then(res => {
            return res
        })
    }
}