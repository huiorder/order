const db = wx.cloud.database()
const local = db.collection("user_location")
import Dialog from 'vant-weapp/dialog/dialog';
const app=getApp()
Page({
    data: {
        newLocal: '',
        _openid: '',
        locationObj: {},
        isDelete: false
    },
    onLoad: function (options) {
        this.myCheckLogin()
    },
    myCheckLogin(){
        // 调用云函数
        wx.cloud.callFunction({
            name: 'login',
            data: {},
            success: res => {
            //console.log('[云函数] [login] user openid: ', res.result.openid)
            this.setData({
                _openid: res.result.openid
            })
            //this.getLocation()
            app.globalData.openid = res.result.openid
            app.globalData.appid=res.result.appid
            },
            fail: err => {
                console.error('[云函数] [login] 调用失败', err)
            }
        })
    },
    onChange(event){
        //添加新地址
        this.setData({
        newLocal: event.detail.value
        })
              
    },
    chooseLocation: function(e){
        wx.chooseLocation({
          success: res => {
            console.log(res)
            let locationObj = {
              latitude: res.latitude,
              longitude: res.longitude,
              name: res.name,
              address: res.address
            }
            this.setData({
                locationObj: locationObj
            })
          },
        })
    },
    onSubmit(){
        if(Object.keys(this.data.locationObj).length === 0){
            Dialog.alert({
                title: '提示',
                message: '请选择位置范围',
              })
        }
        else if(this.data.newLocal == ''){
            Dialog.alert({
                title: '提示',
                message: '请输入详细地址',
              })
        }
        else if((this.data.locationObj.latitude < 40) || (this.data.locationObj.latitude > 42) || (this.data.locationObj.longitude < 116) || (this.data.locationObj.longitude > 120)){
            Dialog.alert({
                title: '提示',
                message: '您所选的位置不在送餐范围内\n请重新选择',
              }).then(() => {
                this.setData({
                    locationObj: {}
                })
              });
        }
        else{
            wx.cloud.callFunction({
                name: 'UserLocation',
                data: {
                    using: 'add',
                    _openid: this.data._openid,
                    location: this.data.newLocal,
                    isDelete: this.data.isDelete
                },
            }).then(res => {
                wx.navigateTo({
                  url: '../user_location/user_location',
                })
            })
        }  
    }
})