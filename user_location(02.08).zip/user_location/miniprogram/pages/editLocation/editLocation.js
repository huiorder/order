//编辑地址（删除地址）
Page({
    data: {
        _openid: '',
        location: [],
        result: []
    },
    onLoad: function (options) {
        var location = wx.getStorageSync('location');
        var _openid = wx.getStorageSync('_openid');
        this.setData({
            location: location,
            _openid: _openid
        })
    },
    onDelete(){
        console.log(this.data.result)
        wx.cloud.callFunction({
            name: 'UserLocation',
            data: {
                using: 'delete',
                _openid: this.data._openid,
                isDelete: true
            },
        }).then(res => {
            console.log(res)
            wx.navigateTo({
              url: '../user_location/user_location',
            })
        })
    },
    //复选框
    onChange(event) {
        this.setData({
          result: event.detail
        });
    },
    toggle(event) {
        const  { index } = event.currentTarget.dataset;
        const checkbox = this.selectComponent(`.checkboxes-${index}`);
        console.log(this.data._openid)
        var value = !checkbox.data.value
        console.log(value)
        console.log(checkbox.data.name)
        wx.cloud.callFunction({
            name: 'UserLocation',
            data: {
                using: 'update',
                _openid: this.data._openid,
                location: checkbox.data.name,
                isDelete: value//更新是否被删除的状态
            }
        }).then(res => {
            console.log(res)
             checkbox.toggle();
         })
        
    },
    
    noop() {}
})