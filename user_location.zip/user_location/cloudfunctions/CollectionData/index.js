const cloud = require('wx-server-sdk')

cloud.init({
    // API 调用都保持和云函数当前所在环境一致
    env: cloud.DYNAMIC_CURRENT_ENV
  })

let db = cloud.database();
exports.main = async (event, context) => {
    if(event.isCollect == true)//添加收藏
    {
        return await db.collection('collect').add({
            data: {
                _openid: event._openid,
                name: event.name,
                desc: event.desc
            }
        }).then(res => {
            console.log("添加成功", res)
            
            return res
        });
    }
    else//取消收藏
    {
        return await db.collection('collect').where({
            _openid: event._openid,
            name: event.name,
            desc: event.desc
        }).remove().then(res => {
            return res
        })
    }
    
}