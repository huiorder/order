const db = wx.cloud.database()
const local = db.collection("user_location")
import Dialog from 'vant-weapp/dialog/dialog';
const app=getApp()
Page({

    /**
     * 页面的初始数据
     */
    data: {
        newLocal: '',
        _openid: '',
        locationObj: {}
    },
    onLoad: function (options) {
        this.myCheckLogin()
    },
    myCheckLogin(){
        // 调用云函数
        wx.cloud.callFunction({
            name: 'login',
            data: {},
            success: res => {
            //console.log('[云函数] [login] user openid: ', res.result.openid)
            this.setData({
                _openid: res.result.openid
            })
            //this.getLocation()
            app.globalData.openid = res.result.openid
            app.globalData.appid=res.result.appid
            },
            fail: err => {
                console.error('[云函数] [login] 调用失败', err)
            }
        })
    },
    onFocus(event){
        console.log(this.data.locationObj)
        if((this.data.locationObj.latitude < 40) || (this.data.locationObj.latitude > 42) || (this.data.locationObj.longitude < 116) || (this.data.locationObj.longitude > 120)){
            Dialog.alert({
                title: '提示',
                message: '您所选的位置不在送餐范围内\n请重新选择',
              }).then(() => {
                this.setData({
                    locationObj: {}
                })
              });
        }
    },
    onChange(event){
        //添加新地址
        this.setData({
            newLocal: event.detail.value
        })
        if(this.data.newLocal != ''){
            wx.cloud.callFunction({
                name: 'UserLocation',
                data: {
                    using: 'add',
                    _openid: this.data._openid,
                    location: this.data.newLocal
                },
            }).then(res => {
                console.log("success")
            })
        }
        
    },
    chooseLocation: function(e){
        wx.chooseLocation({
          success: res => {
            console.log(res)
            let locationObj = {
              latitude: res.latitude,
              longitude: res.longitude,
              name: res.name,
              address: res.address
            }
            this.setData({
                locationObj: locationObj
            })
          },
        })
    },
})