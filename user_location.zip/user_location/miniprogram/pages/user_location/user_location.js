const db = wx.cloud.database()
const local = db.collection("user_location")
const app=getApp()
Page({
    data: {
        location: [],
        newLocal: '',
        _openid: '',
        // locationObj: {}
    },
    onLoad: function (options) {
        this.myCheckLogin()
    },
    myCheckLogin(){
        // 调用云函数
        wx.cloud.callFunction({
            name: 'login',
            data: {},
            success: res => {
            //console.log('[云函数] [login] user openid: ', res.result.openid)
            this.setData({
                _openid: res.result.openid
            })
            this.getLocation()
            app.globalData.openid = res.result.openid
            app.globalData.appid=res.result.appid
            },
            fail: err => {
                console.error('[云函数] [login] 调用失败', err)
            }
        })
    },
    getLocation(){
        wx.cloud.callFunction({
            name: 'UserLocation',
            data: {
                _openid: this.data._openid,
                using: 'get',
            },  
            success: res => {
                this.setData({
                    location: res.result.data
                })
            },
            fail: err => {
                console.error(err)
            }
        })
        
    },
    addLocation(){
        //this.chooseLocation()
        wx.navigateTo({
            url: '../newLocation/newLocation',
        })
    }
})